class Point:
    """Represents a point in 2-D space.

    attributes: x, y
    """